from django.shortcuts import render
from rest_framework import generics
from basic_api.models import Post
from basic_api.serializers import PostSerializer

# Create your views here.
class API_objects(generics.ListCreateAPIView):
    queryset = Post.objects.all()
    serializer_class = PostSerializer

class API_objects_details(generics.RetrieveUpdateDestroyAPIView):
    queryset = Post.objects.all()
    serializer_class = PostSerializer

def homepage(request):
    return render(request,'index.html')
