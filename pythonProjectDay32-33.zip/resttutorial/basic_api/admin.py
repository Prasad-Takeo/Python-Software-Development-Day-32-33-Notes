from django.contrib import admin
from basic_api.models import Post

# Register your models here
admin.site.register(Post)
